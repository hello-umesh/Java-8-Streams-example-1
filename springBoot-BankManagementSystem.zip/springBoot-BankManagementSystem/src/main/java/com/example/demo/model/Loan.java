package com.example.demo.model;
import java.util.Date;

public class Loan {
	private int loanId;
	private String loanType;
	private Long loanAmount;
	private Date dateofLoan;
	private int rateOfInterest;
	private int durationOfLoan;
    private String user_Name;
    
	public Loan() {	}

	public Loan(int loanId, String loanType, Long loanAmount, Date dateofLoan, int rateOfInterest, int durationOfLoan,
			String user_Name) {
		super();
		this.loanId = loanId;
		this.loanType = loanType;
		this.loanAmount = loanAmount;
		this.dateofLoan = dateofLoan;
		this.rateOfInterest = rateOfInterest;
		this.durationOfLoan = durationOfLoan;
		this.user_Name = user_Name;
	}

	public int getLoanId() {
		return loanId;
	}

	public void setLoanId(int loanId) {
		this.loanId = loanId;
	}

	public String getLoanType() {
		return loanType;
	}

	public void setLoanType(String loanType) {
		this.loanType = loanType;
	}

	public Long getLoanAmount() {
		return loanAmount;
	}

	public void setLoanAmount(Long loanAmount) {
		this.loanAmount = loanAmount;
	}

	public Date getDateofLoan() {
		return dateofLoan;
	}

	public void setDateofLoan(Date dateofLoan) {
		this.dateofLoan = dateofLoan;
	}

	public int getRateOfInterest() {
		return rateOfInterest;
	}

	public void setRateOfInterest(int rateOfInterest) {
		this.rateOfInterest = rateOfInterest;
	}

	public int getDurationOfLoan() {
		return durationOfLoan;
	}

	public void setDurationOfLoan(int durationOfLoan) {
		this.durationOfLoan = durationOfLoan;
	}

	public String getUser_Name() {
		return user_Name;
	}

	public void setUser_Name(String user_Name) {
		this.user_Name = user_Name;
	}

	@Override
	public String toString() {
		return "Loan [loanId=" + loanId + ", loanType=" + loanType + ", loanAmount=" + loanAmount + ", dateofLoan="
				+ dateofLoan + ", rateOfInterest=" + rateOfInterest + ", durationOfLoan=" + durationOfLoan
				+ ", user_Name=" + user_Name + "]";
	}
	


}
