package com.example.demo.service;


import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Service;

import com.example.demo.mappers.MyUserRowMapper;
import com.example.demo.model.MyUser;


@Service
public class MyUserDetailsService {

	@Autowired
	private JdbcTemplate jdbcTemplate;

	public List<MyUser> read() {
		return jdbcTemplate.query("SELECT * FROM MyUser", new MyUserRowMapper());
	}
	
	public MyUser getUserByUserName(String userName) {
		String sql = "SELECT * FROM MyUser where userName= ?";
		return jdbcTemplate.queryForObject(sql, new MyUserRowMapper(),userName);
	}
	
	public int create(MyUser user) {
		String sql="INSERT INTO MyUser VALUES(?,?,?,?,?,?,?,?,?,?,?)";
		return jdbcTemplate.update(sql, user.getName(), user.getUserName(), user.getPassword(), user.getAddress(), user.getState(), user.getCountry(), user.getEmail(), user.getPan(), user.getContactNo(), user.getDob(), user.getAccountType());
	}
	
	public MyUser read(String userName) {
		return jdbcTemplate.queryForObject("SELECT * FROM MyUser WHERE userName=?", new MyUserRowMapper(), userName);
	}
	
	public int update(MyUser user) {
		String sql="UPDATE MyUser SET name=?, password=?, address=?, state=?, country=?, email=?, pan=?, contactNo=?, dob=?, accountType=? WHERE userName=?";
		return jdbcTemplate.update(sql, user.getName(), user.getPassword(), user.getAddress(), user.getState(), user.getCountry(), user.getEmail(), user.getPan(), user.getContactNo(), user.getDob(), user.getAccountType(), user.getUserName());
	}
	
}
