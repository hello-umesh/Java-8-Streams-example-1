package com.example.demo.service;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.dao.LoanDao;
import com.example.demo.model.Loan;


@Service
public class LoanService {
	
	@Autowired
	private LoanDao ldao;
	
	public int create(Loan Loan)
	{
		return ldao.create(Loan);
	}

	public List<Loan> read()
	{
		return ldao.read();
	}

	public Loan read(String userName)
	{
		return ldao.read(userName);
	}

}
