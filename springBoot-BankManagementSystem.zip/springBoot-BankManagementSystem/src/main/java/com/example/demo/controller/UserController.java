package com.example.demo.controller;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Properties;

import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.PasswordAuthentication;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.model.MyUser;
import com.example.demo.service.MyUserDetailsService;

@RestController
public class UserController {

	@Autowired
	private MyUserDetailsService ms;
	
	@GetMapping("/")
	public String home()
	{
		return "Hello Bank Project (User Controller)";
	}
	
	@GetMapping("/user")
	public List<MyUser> getAllUsers()
	{
		List<MyUser> usersList = ms.read();
	    System.out.println("Getting All Users: "+ usersList);
		return usersList;
	}
	
	@GetMapping("/user/{userName}")
	public MyUser getUserByUserName(@PathVariable String userName)
	{
		MyUser user = ms.getUserByUserName(userName);
		System.out.println("Getting UserDetails of UserName "+ userName + " : " + user);
		return user;
	}
	
	@PostMapping("/user")
	public ResponseEntity<String> signup(@RequestBody MyUser user)
	{
		ResponseEntity<String> response = null;
			try {
				if(ms.read(user.getUserName()) == null) {
					ms.create(user);
				String info = "User is Successfully Registered " + user;
				response = new ResponseEntity<String>(info,HttpStatus.OK);
				System.out.println(info);
				return response;
				}
				String info = "User is already have registered with UserName " + user.getUserName();
				response = new ResponseEntity<String>(info,HttpStatus.OK);
			}
			catch(Exception exception){
				String info =  "Please Enter the details in Correct Format";
				response = new ResponseEntity<String>(info,HttpStatus.BAD_REQUEST);
				System.out.println(info);
			}
			return response;
	}
	
	@GetMapping("/user/{username}/{password}")
	public ResponseEntity<String> login(@PathVariable String username, @PathVariable String password)
	{
		ResponseEntity<String> response = null;
		try {
			MyUser user = ms.read(username);
			if(user.getPassword().equals(password)) {
				System.out.println( user + " User is Successfully LoggedIn");
				String info = " User is Successfully LoggedIn: "+ user;
				response = new ResponseEntity<String>(info,HttpStatus.OK);
				return response;
				}
			String info= " Incorrect Password is Entered, Please Enter Correct Password";
			response = new ResponseEntity<String>(info,HttpStatus.NOT_FOUND);
		   }
		catch(Exception exception){
			String info =  "No registered User is found with the "+ username;
			response = new ResponseEntity<String>(info,HttpStatus.NOT_FOUND);
			System.out.println(info);
		}
		return response;
	}

	@PutMapping("/user")
	public ResponseEntity<String> modifyUser(@RequestBody MyUser user)
	{
//		System.out.println( user.getUserName() + " User is Updating the Account Details: " + user);
		ResponseEntity<String> response = null;
		try {
			ms.update(user);
			String info = "User Account Details are Successfully updated\n" + user;
			response = new ResponseEntity<String>(info,HttpStatus.OK);
			System.out.println(info);
		}
		catch(Exception exception){
			String info =  "Please Enter the details in Correct Format";
			response = new ResponseEntity<String>(info,HttpStatus.BAD_REQUEST);
			System.out.println(info);
		}
		return response;
		
	}
	
}

