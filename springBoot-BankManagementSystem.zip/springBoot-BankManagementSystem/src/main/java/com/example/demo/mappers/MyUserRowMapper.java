package com.example.demo.mappers;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.ParseException;
import java.text.SimpleDateFormat;

import org.springframework.jdbc.core.RowMapper;

import com.example.demo.model.MyUser;

public class MyUserRowMapper implements RowMapper<MyUser>
{

	@Override
	public MyUser mapRow(ResultSet rs, int rowNum) throws SQLException {
		SimpleDateFormat sdf=new SimpleDateFormat("yyyy-MM-dd");
		MyUser user=null;
			try {
				user=new MyUser(rs.getString(1),rs.getString(2),rs.getString(3),rs.getString(4),rs.getString(5),rs.getString(6),rs.getString(7),rs.getString(8),rs.getString(9),sdf.parse(rs.getString(10)),rs.getString(11));
			} catch (ParseException e) {
				user=null;
			}
		return user;
	}
	
}

