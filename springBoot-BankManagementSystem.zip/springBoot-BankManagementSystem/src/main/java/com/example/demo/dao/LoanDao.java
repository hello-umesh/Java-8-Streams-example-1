package com.example.demo.dao;

import java.util.List;

import com.example.demo.model.Loan;


public interface LoanDao {

	int create(Loan Loan);

	List<Loan> read();

	Loan read(String userName);

}