package com.example.demo.model;

import java.util.Date;

public class MyUser
{
	
	private String name;
	private String userName;
	private String password;
	private String address;
	private String state;
	private String country;
	private String email;
	private String pan;
	private String contactNo;
	private Date dob;
	private String accountType;
	
	MyUser() {}

	public MyUser(String name, String userName, String password, String address, String state, String country,
			String email, String pan, String contactNo, Date dob, String accountType) {
		super();
		this.name = name;
		this.userName = userName;
		this.password = password;
		this.address = address;
		this.state = state;
		this.country = country;
		this.email = email;
		this.pan = pan;
		this.contactNo = contactNo;
		this.dob = dob;
		this.accountType = accountType;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public String getState() {
		return state;
	}

	public void setState(String state) {
		this.state = state;
	}

	public String getCountry() {
		return country;
	}

	public void setCountry(String country) {
		this.country = country;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getPan() {
		return pan;
	}

	public void setPan(String pan) {
		this.pan = pan;
	}

	public String getContactNo() {
		return contactNo;
	}

	public void setContactNo(String contactNo) {
		this.contactNo = contactNo;
	}

	public Date getDob() {
		return dob;
	}

	public void setDob(Date dob) {
		this.dob = dob;
	}

	public String getAccountType() {
		return accountType;
	}

	public void setAccountType(String accountType) {
		this.accountType = accountType;
	}

	@Override
	public String toString() {
		return "MyUser [name=" + name + ", userName=" + userName + ", password=" + password + ", address=" + address
				+ ", state=" + state + ", country=" + country + ", email=" + email + ", pan=" + pan + ", contactNo="
				+ contactNo + ", dob=" + dob + ", accountType=" + accountType + "]";
	}
	
}
