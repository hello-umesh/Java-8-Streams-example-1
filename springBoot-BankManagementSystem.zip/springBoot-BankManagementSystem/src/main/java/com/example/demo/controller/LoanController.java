package com.example.demo.controller;
import java.util.Collections;
import java.util.List;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.model.Loan;
import com.example.demo.model.MyUser;
import com.example.demo.service.LoanService;


@RestController
@CrossOrigin({"http://localhost:4200","*"})
public class LoanController {
	
	@Autowired
	private LoanService ls;
	
	@PostMapping("/loan")
	public int applyLoan(@RequestBody Loan Loan)
	{ 

	   System.out.println( Loan.getUser_Name() + "is Applying for Loan: "+ Loan);	
		return ls.create(Loan);
	}
	
	@GetMapping("/loan")
	public List<Loan> getAllLoans()
	{
		List<Loan> loansList = ls.read();
	    System.out.println("Getting List of all Applied Loans: "+ loansList);
		return loansList;
	}
	
	@GetMapping("/loan/{userName}")
	public Loan getLoanByUserName(@PathVariable String userName)
	{
		Loan loanDetails = ls.read(userName);
	    System.out.println("Getting Loan Details of userName "+ userName + " : "+ loanDetails);
		return loanDetails;
	}
	
	@GetMapping("/loan/filter/{amount}")
	public ResponseEntity<String> getCustomersByfilterAmount(@PathVariable Long amount)
	{ 
		ResponseEntity<String> response = null;
		try {
			List<Loan> list = ls.read();
			List<String> Customers = list.stream()  
	         .filter(l -> l.getLoanAmount() > amount)
			 .map(u -> u.getUser_Name())
			 .collect(Collectors.toList());
			
		    if(Customers.size()>1) {
			String info = " Customers with applied Loan greater than "  +amount + " : " + Customers ;
			response = new ResponseEntity<String>(info,HttpStatus.OK);
			System.out.println(info);
			}else {
				String info = "No Customers Found with Loan amount greater than " + amount ;
				response = new ResponseEntity<String>(info,HttpStatus.NOT_FOUND);
	           System.out.println(info);
			}
		}
		catch(Exception exception){
			String info = "Something Went Wrong , Try with correct inputs"  ;
			response = new ResponseEntity<String>(info,HttpStatus.BAD_REQUEST);
			System.out.println(info);
		}
		return response;
	}
}
