package com.example.demo.mappers;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Component;
import com.example.demo.model.Loan;

@Component
public class LoanRowMapper implements RowMapper<Loan>
{

	@Override
	public Loan mapRow(ResultSet rs, int rowNum) throws SQLException {
		SimpleDateFormat sdf=new SimpleDateFormat("yyyy-MM-dd");
		Loan loan=null;
			try {
				loan=new Loan(rs.getInt(1), rs.getString(2), rs.getLong(3),sdf.parse(rs.getString(4)), rs.getInt(5), rs.getInt(6), rs.getString(7));
			} catch (ParseException e) {
				loan=null;
			}
		return loan;
	}

}
