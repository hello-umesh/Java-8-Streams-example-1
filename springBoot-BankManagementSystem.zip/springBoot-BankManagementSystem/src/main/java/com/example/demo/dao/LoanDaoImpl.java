package com.example.demo.dao;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Component;

import com.example.demo.mappers.LoanRowMapper;
import com.example.demo.model.Loan;

@Component
public class LoanDaoImpl implements LoanDao  {
	@Autowired
	private JdbcTemplate jdbcTemplate;
	
	@Override
	public int create(Loan loan) {
		System.out.println("Insert Loan Details: "+ loan);
		return jdbcTemplate.update("INSERT INTO loan VALUES (?,?,?,?,?,?,?)", loan.getLoanId(), loan.getLoanType(), loan.getLoanAmount(), loan.getDateofLoan(), loan.getRateOfInterest(), loan.getDurationOfLoan(), loan.getUser_Name());
	}
	
	@Override
	public List<Loan> read() {
		return jdbcTemplate.query("SELECT * FROM loan ", new LoanRowMapper());
	}
	
	@Override
	public Loan read(String userName) {
		return jdbcTemplate.queryForObject("SELECT * FROM loan WHERE user_Name=?", new LoanRowMapper(), userName);
	}
	
	
}
