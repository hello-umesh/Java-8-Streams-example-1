package com.rdp.spring.boot.HospitalFrontDesk.pojo;

import java.util.ArrayList;
import java.util.List;


public class Hospital {
	
	private int hospitalId;
	private String hospitalName;
	
	public Hospital(int hospitalId, String hospitalName) {
		super();
		this.hospitalId = hospitalId;
		this.hospitalName = hospitalName;
	}
	
	
	public int getHospitalId() {
		return hospitalId;
	}
	public void setHospitalId(int hospitalId) {
		this.hospitalId = hospitalId;
	}
	public String getHospitalName() {
		return hospitalName;
	}
	public void setHospitalName(String hospitalName) {
		this.hospitalName = hospitalName;
	}
	
	
	public static List<Hospital> getHospitalList() {
		List<Hospital> hospitals = new ArrayList<Hospital>();

		hospitals.add(new Hospital(954, "AMRI"));
		hospitals.add(new Hospital(946, "APOLLO"));
		hospitals.add(new Hospital(851, "AIIMS"));
		hospitals.add(new Hospital(785, "COLUMBIA-ASIA"));
		return hospitals;
	}
	
}
