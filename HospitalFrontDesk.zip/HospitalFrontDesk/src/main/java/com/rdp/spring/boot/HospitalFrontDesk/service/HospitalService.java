package com.rdp.spring.boot.HospitalFrontDesk.service;

import java.util.ArrayList;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.stereotype.Service;
import com.rdp.spring.boot.HospitalFrontDesk.controller.AppProps;
import com.rdp.spring.boot.HospitalFrontDesk.controller.AppProps.Specialist;
import com.rdp.spring.boot.HospitalFrontDesk.exception.HospitalException;
import com.rdp.spring.boot.HospitalFrontDesk.pojo.Appointment;
import com.rdp.spring.boot.HospitalFrontDesk.pojo.Hospital;
import com.rdp.spring.boot.HospitalFrontDesk.pojo.Patient;

@Service
public class HospitalService {
	
	@Autowired
	AppProps properties;
	
	@Cacheable("specialistListInDetail")
	public List<Specialist> getAllSpecialist(String hospitalName,String specialistType) throws HospitalException {
		List<Specialist> specialistList = new ArrayList<Specialist>();
		for (Specialist specialist : properties.getList()) {
			if(specialist.getType().equalsIgnoreCase(specialistType)) {
				for(Hospital hospital : Hospital.getHospitalList()) {
					if(hospital.getHospitalId()==specialist.getHospitalId() && 
							hospital.getHospitalName().equalsIgnoreCase(hospitalName)) {
						specialistList.add(specialist);
					} 
				} 
			}
		}
		if(specialistList.isEmpty() || specialistList.size()==0) {
			throw new HospitalException("no specialist details found for the specified hospital name");
		}

		return specialistList;
	}
	
	public Appointment createAppointMent(String specialistName, String appointmentDay, String patientName ) throws HospitalException  {
		Appointment appointment = null;
		
		List<Specialist> specialistList = properties.getList();
		for(Specialist specialist : specialistList) {
			if(specialistName.equals(specialist.getName()) && specialist.getAvailableday().contains(appointmentDay)) {
				appointment = new Appointment();
				appointment.setAppointmentDay(appointmentDay);
				appointment.setAppointmentTime(specialist.getAvailableTime());
				appointment.setPatientName(patientName);
				appointment.setSpecialistName(specialist.getName());
			}
		}
		if(appointment == null) {
			throw new HospitalException("no specialist details found for the specified hospital name");
		}
		return appointment;
	}

	public String getNoOfBedAvailable(String hospitalName) throws HospitalException {
		List<Patient> patientList = null;
		String bedStatus = "";
		
		
		if(hospitalName.equalsIgnoreCase("AMRI")) {
			patientList = Patient.getPatientListforAMRI();
		} 
		if(hospitalName.equalsIgnoreCase("APOLLO")) {
			patientList = Patient.getPatientListforAPOLLO();
		}
		if(hospitalName.equalsIgnoreCase("AIIMS")) {
			patientList = Patient.getPatientListforAIIMS();
		}
		if(hospitalName.equalsIgnoreCase("COLUMBIA-ASIA")) {
			patientList = Patient.getPatientListforCOLUMBIAASIA();
		}
		
		int count = 0;
		if(patientList!=null) {
			for(Patient patient: patientList) {
				if(patient.getPatientStatus().equalsIgnoreCase("DISCHARGE")) {
					count++;
				}
			}
		} else {
			throw new HospitalException("Hospital Name is invalid");
		}
		
		if(count >0) {
			bedStatus = "Number of Beds Available is = "+count;
		} else  {
			throw new HospitalException("No beds are available for Admission");
		}
		return bedStatus;
	}
}
