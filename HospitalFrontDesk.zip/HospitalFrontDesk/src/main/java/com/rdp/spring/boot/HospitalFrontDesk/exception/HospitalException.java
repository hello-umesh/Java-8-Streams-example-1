package com.rdp.spring.boot.HospitalFrontDesk.exception;

import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.ResponseStatus;

@ResponseStatus(code=HttpStatus.NOT_FOUND)
public class HospitalException  extends Exception{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	

	public HospitalException() {
		super();
	}
	
	public HospitalException(String message) {
		super(message);
	}
}
