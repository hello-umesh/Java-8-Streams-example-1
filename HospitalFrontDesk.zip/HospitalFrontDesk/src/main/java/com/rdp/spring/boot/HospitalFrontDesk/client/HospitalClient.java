package com.rdp.spring.boot.HospitalFrontDesk.client;

import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.util.UriComponentsBuilder;

import com.rdp.spring.boot.HospitalFrontDesk.controller.AppProps.Specialist;

@Component
public class HospitalClient {

	@Autowired
	private RestTemplate template;

	@Autowired
	private Environment env;

	public ResponseEntity<Specialist[]> getAllSpecialistJSON() {
		HttpHeaders headers = new HttpHeaders();
		headers.setAccept(Arrays.asList(MediaType.APPLICATION_JSON));
		HttpEntity<String> entity = new HttpEntity<String>("parameters", headers);

		String url = env.getProperty("url.client.getSpecialistList");

		Map<String, String> urlParams = new HashMap<String, String>();

		urlParams.put("hospitalName", "COLUMBIA-ASIA");
		urlParams.put("specialistType", "Gastroenterology");

		UriComponentsBuilder builder = UriComponentsBuilder.fromHttpUrl(url);

		ResponseEntity<Specialist[]> result = template.exchange(builder.buildAndExpand(urlParams).toUri(),
				HttpMethod.GET, entity, Specialist[].class);

		return result;
	}

	public ResponseEntity<Specialist[]> getAllSpecialistXML() {
		HttpHeaders headers = new HttpHeaders();
		headers.setAccept(Arrays.asList(MediaType.APPLICATION_XML));
		HttpEntity<String> entity = new HttpEntity<String>("parameters", headers);

		String url = env.getProperty("url.client.getSpecialistList");

		Map<String, String> urlParams = new HashMap<String, String>();

		urlParams.put("hospitalName", "COLUMBIA-ASIA");
		urlParams.put("specialistType", "Gastroenterology");

		UriComponentsBuilder builder = UriComponentsBuilder.fromHttpUrl(url);

		ResponseEntity<Specialist[]> result = template.exchange(builder.buildAndExpand(urlParams).toUri(),
				HttpMethod.GET, entity, Specialist[].class);

		return result;
	}

}
