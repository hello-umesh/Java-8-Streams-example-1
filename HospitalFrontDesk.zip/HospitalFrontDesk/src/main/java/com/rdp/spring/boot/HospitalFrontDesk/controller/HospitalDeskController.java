package com.rdp.spring.boot.HospitalFrontDesk.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import com.rdp.spring.boot.HospitalFrontDesk.controller.AppProps.Specialist;
import com.rdp.spring.boot.HospitalFrontDesk.exception.HospitalException;
import com.rdp.spring.boot.HospitalFrontDesk.pojo.Appointment;
import com.rdp.spring.boot.HospitalFrontDesk.service.HospitalService;

@RestController
@RequestMapping("/HospitalFrontDesk")
public class HospitalDeskController {
	
	@Autowired
	HospitalService service;
	
		
	@GetMapping("${url.getSpecialistList}")
	public List<Specialist> getSpecialistList(@PathVariable("hospitalName") String hospitalName, 
						@PathVariable("specialistType") String specialistType) throws HospitalException {
		
		return service.getAllSpecialist(hospitalName,specialistType);
		 
	}
	
	@PostMapping("${url.createAppointment}")
	public Appointment createAppointment(@PathVariable("specialistName") String specialistName, 
					@PathVariable("appointmentDay") String appointmentDay, @PathVariable("patientName") String patientName) throws HospitalException {
		return service.createAppointMent(specialistName, appointmentDay, patientName);
	}
	
	@GetMapping("${url.getBedCount}")
	public String getNoOfBedAvailable (@PathVariable("hospitalName") String hospitalName) throws HospitalException {
		return service.getNoOfBedAvailable(hospitalName);
	}

}
