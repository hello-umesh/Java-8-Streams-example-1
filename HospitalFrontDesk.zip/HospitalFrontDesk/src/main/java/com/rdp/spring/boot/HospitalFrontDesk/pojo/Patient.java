package com.rdp.spring.boot.HospitalFrontDesk.pojo;

import java.util.ArrayList;
import java.util.List;

public class Patient {
	
	private String patientName;
	private String patientStatus;
	
	public Patient(String patientName,String patientStatus) {
		this.patientName = patientName;
		this.patientStatus = patientStatus;
	}
	
	public String getPatientStatus() {
		return patientStatus;
	}
	public void setPatientStatus(String patientStatus) {
		this.patientStatus = patientStatus;
	}
	public String getPatientName() {
		return patientName;
	}
	public void setPatientName(String patientName) {
		this.patientName = patientName;
	}
	
	public static List<Patient> getPatientListforAMRI() {

		List<Patient> patients = new ArrayList<Patient>();

		patients.add(new Patient("Ram", "Admitted"));
		patients.add(new Patient("Rahim", "DISCHARGE"));
		patients.add(new Patient("Saurav", "Admitted"));
		patients.add(new Patient("Pinaki", "Admitted"));
		return patients;

	}

	public static List<Patient> getPatientListforAPOLLO() {

		List<Patient> patients = new ArrayList<Patient>();
		patients.add(new Patient("Sumanta", "Admitted"));
		patients.add(new Patient("Anish", "DISCHARGE"));
		patients.add(new Patient("Dharmesh", "DISCHARGE"));
		patients.add(new Patient("Amit", "Admitted"));
		return patients;
	}

	public static List<Patient> getPatientListforAIIMS() {

		List<Patient> patients = new ArrayList<Patient>();
		patients.add(new Patient("Rakesh", "DISCHARGE"));
		patients.add(new Patient("Souvik", "DISCHARGE"));
		patients.add(new Patient("Vijay", "Admitted"));
		patients.add(new Patient("Devesh", "Admitted"));
		return patients;
	}

	public static List<Patient> getPatientListforCOLUMBIAASIA() {

		List<Patient> patients = new ArrayList<Patient>();
		patients.add(new Patient("Ravi", "DISCHARGE"));
		patients.add(new Patient("Chitta", "DISCHARGE"));
		patients.add(new Patient("Digvijay", "DISCHARGE"));
		patients.add(new Patient("Tiger", "Admitted"));

		return patients;

	}

}
